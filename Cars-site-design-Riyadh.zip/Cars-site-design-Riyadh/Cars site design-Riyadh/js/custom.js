$(document).ready(function(){
	
	
$('.mySlider').slick({
        dots: true,
		infinite: true,
		speed: 300,
		prevArrow: '.prev',
		nextArrow: '.next',
	});
	
	
});